package com.custom.touchpulse.alt

import android.view.MotionEvent
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Имитация силы нажатия с динамическим верхним пределом шкалы (1.0x .. scaleCeiling):
 * если в отдельном окне задан потолок (например, 100.0), то шкалы X и Y строятся от 1.0 до 100.0.
 */
object PressureCurveEngine {

    private var minContactObserved = 0.08f
    private var maxContactObserved = 0.45f

    data class ScaleResult(
        val rawNormalizedForce: Float,
        val cappedNormalizedForce: Float,
        val scaleX: Float,
        val scaleY: Float,
        val maxDeltaPx: Float
    )

    fun evaluate(
        event: MotionEvent,
        baseX: Float,
        maxX: Float,
        baseY: Float,
        maxY: Float,
        curveExponent: Float,
        forceCapFraction: Float = 1.0f,
        scaleCeiling: Float = 100.0f,
        maxDeltaPx: Float = 240f
    ): ScaleResult {
        val ceiling = scaleCeiling.coerceIn(1.0f, 500.0f)
        val safeBaseX = baseX.coerceIn(1.0f, ceiling)
        val safeMaxX = maxX.coerceIn(1.0f, ceiling)
        val safeBaseY = baseY.coerceIn(1.0f, ceiling)
        val safeMaxY = maxY.coerceIn(1.0f, ceiling)

        val rawSize = event.size.coerceIn(0f, 1f)
        val rawMajor = (event.touchMajor / 120f).coerceIn(0f, 1f)
        val rawPressure = if (event.pressure in 0.01f..0.99f) event.pressure else rawSize

        val contactMetric = max(rawSize, rawMajor * 0.75f + rawPressure * 0.25f)

        if (contactMetric > 0.01f) {
            minContactObserved = min(minContactObserved, contactMetric)
            maxContactObserved = max(maxContactObserved, contactMetric)
        }

        val span = (maxContactObserved - minContactObserved).coerceAtLeast(0.05f)
        val normalized = ((contactMetric - minContactObserved) / span).coerceIn(0f, 1f)

        val cappedForce = normalized.coerceIn(0f, forceCapFraction.coerceIn(0.05f, 1.0f))
        val curved = cappedForce.pow(curveExponent.coerceIn(0.5f, 3.0f))

        val effectiveX = (safeBaseX + (safeMaxX - safeBaseX) * curved).coerceIn(1.0f, ceiling)
        val effectiveY = (safeBaseY + (safeMaxY - safeBaseY) * curved).coerceIn(1.0f, ceiling)

        return ScaleResult(
            rawNormalizedForce = normalized,
            cappedNormalizedForce = curved,
            scaleX = effectiveX,
            scaleY = effectiveY,
            maxDeltaPx = maxDeltaPx.coerceIn(10f, 500f)
        )
    }
}
