package com.custom.touchpulse.alt

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class TouchBoosterService : AccessibilityService() {

    private var currentPackage: String = ""
    private var sensorOverlay: View? = null
    private var windowManager: WindowManager? = null

    private var lastRawX = 0f
    private var lastRawY = 0f
    private var isDispatching = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        attachEdgeSensorOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != packageName) {
            currentPackage = pkg
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun attachEdgeSensorOverlay() {
        if (!Settings.canDrawOverlays(this) || sensorOverlay != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val view = object : View(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean {
                handleTouchSample(event)
                return false
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            1,
            1,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager?.addView(view, params)
            sensorOverlay = view
        } catch (_: Exception) {
        }
    }

    private fun handleTouchSample(event: MotionEvent) {
        if (isDispatching) return

        val prefs = getSharedPreferences("touch_pulse_prefs", Context.MODE_PRIVATE)
        val targetPkg = prefs.getString("target_pkg", "com.dts.freefireth")?.trim().orEmpty()
        if (targetPkg.isNotEmpty() && currentPackage != targetPkg) return

        val scaleCeiling = prefs.getFloat("scale_ceiling", 100.0f).coerceIn(1.0f, 500.0f)
        val baseX = prefs.getFloat("base_x", 1.0f)
        val maxX = prefs.getFloat("max_x", 3.5f)
        val baseY = prefs.getFloat("base_y", 1.0f)
        val maxY = prefs.getFloat("max_y", 4.5f)
        val curve = prefs.getFloat("curve", 1.5f)
        val forceCapFraction = prefs.getFloat("force_cap_fraction", 1.0f)
        val maxDeltaPx = prefs.getFloat("max_delta_px", 240f)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastRawX
                val dy = event.rawY - lastRawY
                lastRawX = event.rawX
                lastRawY = event.rawY

                if (dx == 0f && dy == 0f) return

                val result = PressureCurveEngine.evaluate(
                    event = event,
                    baseX = baseX,
                    maxX = maxX,
                    baseY = baseY,
                    maxY = maxY,
                    curveExponent = curve,
                    forceCapFraction = forceCapFraction,
                    scaleCeiling = scaleCeiling,
                    maxDeltaPx = maxDeltaPx
                )

                val extraDx = (dx * (result.scaleX - 1.0f)).coerceIn(-result.maxDeltaPx, result.maxDeltaPx)
                val extraDy = (dy * (result.scaleY - 1.0f)).coerceIn(-result.maxDeltaPx, result.maxDeltaPx)

                if (kotlin.math.abs(extraDx) > 1.5f || kotlin.math.abs(extraDy) > 1.5f) {
                    dispatchBoostedDelta(event.rawX, event.rawY, extraDx, extraDy)
                }
            }
        }
    }

    private fun dispatchBoostedDelta(startX: Float, startY: Float, extraDx: Float, extraDy: Float) {
        val dm = resources.displayMetrics
        val endX = (startX + extraDx).coerceIn(1f, dm.widthPixels - 1f)
        val endY = (startY + extraDy).coerceIn(1f, dm.heightPixels - 1f)

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0L, 12L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        isDispatching = true
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                isDispatching = false
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                isDispatching = false
            }
        }, null)
    }

    private fun removeOverlay() {
        sensorOverlay?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        sensorOverlay = null
    }
}
