package com.custom.touchpulse.alt

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MaxScaleWindowActivity : AppCompatActivity() {

    private lateinit var tvRangePreview: TextView
    private lateinit var etMaxScaleCeiling: EditText
    private lateinit var sbCeilingSlider: SeekBar
    private lateinit var tvCeilingSliderLabel: TextView
    private var isSyncingUi = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_max_scale_window)

        tvRangePreview = findViewById(R.id.tvWindowRangePreview)
        etMaxScaleCeiling = findViewById(R.id.etMaxScaleCeiling)
        sbCeilingSlider = findViewById(R.id.sbCeilingSlider)
        tvCeilingSliderLabel = findViewById(R.id.tvCeilingSliderLabel)

        val prefs = getSharedPreferences("touch_pulse_prefs", Context.MODE_PRIVATE)
        val currentCeiling = prefs.getFloat("scale_ceiling", 100.0f).coerceIn(1.0f, 500.0f)

        setCeilingValue(currentCeiling, updateTextField = true, updateSlider = true)

        sbCeilingSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (isSyncingUi) return
                val value = 1.0f + (progress / 10.0f)
                setCeilingValue(value, updateTextField = true, updateSlider = false)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        etMaxScaleCeiling.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isSyncingUi) return
                val parsed = s?.toString()?.trim()?.replace(',', '.')?.toFloatOrNull() ?: return
                val clamped = parsed.coerceIn(1.0f, 500.0f)
                setCeilingValue(clamped, updateTextField = false, updateSlider = true)
            }
        })

        findViewById<Button>(R.id.btnApplyCeiling).setOnClickListener {
            val rawInput = etMaxScaleCeiling.text.toString().trim().replace(',', '.').toFloatOrNull()
            val sliderVal = 1.0f + (sbCeilingSlider.progress / 10.0f)
            val finalCeiling = (rawInput ?: sliderVal).coerceIn(1.0f, 500.0f)

            prefs.edit().putFloat("scale_ceiling", finalCeiling).apply()
            Toast.makeText(
                this,
                String.format(Locale.US, "Диапазон X/Y задан: от 1.0 до %.1f", finalCeiling),
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }

    private fun setCeilingValue(value: Float, updateTextField: Boolean, updateSlider: Boolean) {
        isSyncingUi = true
        val clamped = value.coerceIn(1.0f, 500.0f)
        tvRangePreview.text = String.format(Locale.US, "Текущая шкала X/Y: от 1.0x до %.1fx", clamped)
        tvCeilingSliderLabel.text = String.format(Locale.US, "Быстрый ползунок потолка: %.1fx", clamped)

        if (updateSlider) {
            sbCeilingSlider.progress = ((clamped - 1.0f) * 10f).toInt().coerceIn(0, 4990)
        }
        if (updateTextField) {
            etMaxScaleCeiling.setText(String.format(Locale.US, "%.1f", clamped))
            etMaxScaleCeiling.setSelection(etMaxScaleCeiling.text.length)
        }
        isSyncingUi = false
    }
}
