package com.custom.touchpulse.alt

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var tvStatus: TextView
    private lateinit var tvScaleBoundsInfo: TextView
    private lateinit var etTargetPackage: EditText

    private lateinit var sbBaseX: SeekBar
    private lateinit var sbMaxX: SeekBar
    private lateinit var sbBaseY: SeekBar
    private lateinit var sbMaxY: SeekBar
    private lateinit var sbCurve: SeekBar

    private lateinit var sbForceCap: SeekBar
    private lateinit var sbDeltaCap: SeekBar

    private lateinit var tvBaseX: TextView
    private lateinit var tvMaxX: TextView
    private lateinit var tvBaseY: TextView
    private lateinit var tvMaxY: TextView
    private lateinit var tvCurve: TextView
    private lateinit var tvForceCap: TextView
    private lateinit var tvDeltaCap: TextView
    private lateinit var tvTestPad: TextView

    private var scaleCeiling: Float = 100.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("touch_pulse_prefs", Context.MODE_PRIVATE)

        tvStatus = findViewById(R.id.tvStatus)
        tvScaleBoundsInfo = findViewById(R.id.tvScaleBoundsInfo)
        etTargetPackage = findViewById(R.id.etTargetPackage)

        sbBaseX = findViewById(R.id.sbBaseX)
        sbMaxX = findViewById(R.id.sbMaxX)
        sbBaseY = findViewById(R.id.sbBaseY)
        sbMaxY = findViewById(R.id.sbMaxY)
        sbCurve = findViewById(R.id.sbCurve)

        sbForceCap = findViewById(R.id.sbForceCap)
        sbDeltaCap = findViewById(R.id.sbDeltaCap)

        tvBaseX = findViewById(R.id.tvBaseX)
        tvMaxX = findViewById(R.id.tvMaxX)
        tvBaseY = findViewById(R.id.tvBaseY)
        tvMaxY = findViewById(R.id.tvMaxY)
        tvCurve = findViewById(R.id.tvCurve)
        tvForceCap = findViewById(R.id.tvForceCap)
        tvDeltaCap = findViewById(R.id.tvDeltaCap)
        tvTestPad = findViewById(R.id.tvTestPad)

        etTargetPackage.setText(prefs.getString("target_pkg", "com.dts.freefireth"))

        sbCurve.progress = ((prefs.getFloat("curve", 1.5f) - 0.5f) * 10).toInt().coerceIn(0, 25)
        val forceCapPct = (prefs.getFloat("force_cap_fraction", 1.0f) * 100f).toInt().coerceIn(5, 100)
        sbForceCap.progress = (forceCapPct - 5).coerceIn(0, 95)
        sbDeltaCap.progress = ((prefs.getFloat("max_delta_px", 240f) - 10f) / 10f).toInt().coerceIn(0, 50)

        syncSlidersToCeiling(loadSavedValues = true)

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabels()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

        listOf(
            sbBaseX, sbMaxX, sbBaseY, sbMaxY, sbCurve,
            sbForceCap, sbDeltaCap
        ).forEach { it.setOnSeekBarChangeListener(listener) }

        findViewById<Button>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnEnableOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Разрешение поверх окон уже выдано", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnOpenMaxScaleWindow).setOnClickListener {
            startActivity(Intent(this, MaxScaleWindowActivity::class.java))
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.edit()
                .putString("target_pkg", etTargetPackage.text.toString().trim())
                .putFloat("scale_ceiling", scaleCeiling)
                .putFloat("base_x", progressToScale(sbBaseX.progress))
                .putFloat("max_x", progressToScale(sbMaxX.progress))
                .putFloat("base_y", progressToScale(sbBaseY.progress))
                .putFloat("max_y", progressToScale(sbMaxY.progress))
                .putFloat("curve", progressToCurve(sbCurve.progress))
                .putFloat("force_cap_fraction", progressToForceCapFraction(sbForceCap.progress))
                .putFloat("max_delta_px", progressToDeltaCapPx(sbDeltaCap.progress))
                .apply()
            Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
        }

        tvTestPad.setOnTouchListener { _, event ->
            val res = PressureCurveEngine.evaluate(
                event = event,
                baseX = progressToScale(sbBaseX.progress),
                maxX = progressToScale(sbMaxX.progress),
                baseY = progressToScale(sbBaseY.progress),
                maxY = progressToScale(sbMaxY.progress),
                curveExponent = progressToCurve(sbCurve.progress),
                forceCapFraction = progressToForceCapFraction(sbForceCap.progress),
                scaleCeiling = scaleCeiling,
                maxDeltaPx = progressToDeltaCapPx(sbDeltaCap.progress)
            )
            tvTestPad.text = String.format(
                Locale.US,
                "Шкала: 1.0 — %.1f | Сила: %.0f%%
X: %.2fx | Y: %.2fx | Шаг: %.0f px",
                scaleCeiling,
                res.rawNormalizedForce * 100f,
                res.scaleX,
                res.scaleY,
                res.maxDeltaPx
            )
            true
        }
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        val accOk = isAccessibilityEnabled()
        tvStatus.text = "Accessibility: ${if (accOk) "ВКЛ" else "ВЫКЛ"} | Overlay: ${if (overlayOk) "ВКЛ" else "ВЫКЛ"}"

        val newCeiling = prefs.getFloat("scale_ceiling", 100.0f).coerceIn(1.0f, 500.0f)
        if (newCeiling != scaleCeiling) {
            syncSlidersToCeiling(loadSavedValues = false, overrideCeiling = newCeiling)
        } else {
            updateLabels()
        }
    }

    private fun syncSlidersToCeiling(loadSavedValues: Boolean, overrideCeiling: Float? = null) {
        val currentBaseX = if (loadSavedValues) prefs.getFloat("base_x", 1.0f) else progressToScale(sbBaseX.progress)
        val currentMaxX = if (loadSavedValues) prefs.getFloat("max_x", 3.5f) else progressToScale(sbMaxX.progress)
        val currentBaseY = if (loadSavedValues) prefs.getFloat("base_y", 1.0f) else progressToScale(sbBaseY.progress)
        val currentMaxY = if (loadSavedValues) prefs.getFloat("max_y", 4.5f) else progressToScale(sbMaxY.progress)

        scaleCeiling = (overrideCeiling ?: prefs.getFloat("scale_ceiling", 100.0f)).coerceIn(1.0f, 500.0f)
        val steps = ((scaleCeiling - 1.0f) * 10f).roundToInt().coerceAtLeast(1)

        listOf(sbBaseX, sbMaxX, sbBaseY, sbMaxY).forEach { it.max = steps }

        sbBaseX.progress = scaleToProgress(currentBaseX, steps)
        sbMaxX.progress = scaleToProgress(currentMaxX, steps)
        sbBaseY.progress = scaleToProgress(currentBaseY, steps)
        sbMaxY.progress = scaleToProgress(currentMaxY, steps)

        updateLabels()
    }

    private fun scaleToProgress(value: Float, maxSteps: Int): Int {
        val clamped = value.coerceIn(1.0f, scaleCeiling)
        val ratio = (clamped - 1.0f) / (scaleCeiling - 1.0f).coerceAtLeast(0.1f)
        return (ratio * maxSteps).roundToInt().coerceIn(0, maxSteps)
    }

    private fun progressToScale(p: Int): Float {
        val maxSteps = sbMaxX.max.coerceAtLeast(1)
        val ratio = (p.toFloat() / maxSteps.toFloat()).coerceIn(0f, 1f)
        return 1.0f + ratio * (scaleCeiling - 1.0f)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${TouchBoosterService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun progressToCurve(p: Int): Float = 0.5f + (p / 10.0f)
    private fun progressToForceCapPercent(p: Int): Int = 5 + p
    private fun progressToForceCapFraction(p: Int): Float = progressToForceCapPercent(p) / 100.0f
    private fun progressToDeltaCapPx(p: Int): Float = 10f + (p * 10f)

    private fun updateLabels() {
        tvScaleBoundsInfo.text = String.format(
            Locale.US,
            "Диапазон осей X и Y: от 1.0x до %.1fx",
            scaleCeiling
        )
        tvBaseX.text = String.format(Locale.US, "Множитель X (лёгкое касание): %.1fx", progressToScale(sbBaseX.progress))
        tvMaxX.text = String.format(Locale.US, "Множитель X (сильное нажатие): %.1fx", progressToScale(sbMaxX.progress))
        tvBaseY.text = String.format(Locale.US, "Множитель Y (лёгкое касание): %.1fx", progressToScale(sbBaseY.progress))
        tvMaxY.text = String.format(Locale.US, "Множитель Y (сильное нажатие): %.1fx", progressToScale(sbMaxY.progress))
        tvCurve.text = String.format(Locale.US, "Агрессивность кривой прижатия: %.1f", progressToCurve(sbCurve.progress))
        tvForceCap.text = String.format(Locale.US, "Потолок силы прижатия: %d%%", progressToForceCapPercent(sbForceCap.progress))
        tvDeltaCap.text = String.format(Locale.US, "Лимит добавочного смещения (px/шаг): %.0f px", progressToDeltaCapPx(sbDeltaCap.progress))
    }
}
