# Keep custom classes
-keep class com.custom.touchpulse.alt.** { *; }
